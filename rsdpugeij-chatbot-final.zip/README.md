# Rsdpugeij Chatbot — FINAL Build (Minimal UI in this retry)

Files:
- index.html
- style.css
- app.js
- .nojekyll

Deploy to GitHub Pages and you’re live. Firebase config is embedded. Enable Email/Password + Google in Firebase Authentication and add your GitHub Pages domain to Authorized domains.
